#!/bin/bash

# Variabel untuk GitHub Packages username dan nama image
GITHUB_USERNAME="frisyk" # Ganti dengan username GitHub
IMAGE_NAME="karsajobs"
PROJECT="karsajobs"
TAG="latest"
GITHUB_REPO="ghcr.io/$GITHUB_USERNAME/$PROJECT"

# Build Docker image dari Dockerfile
docker build -t $IMAGE_NAME:$TAG .

# Menampilkan daftar image lokal
docker images

# Menamai ulang image agar sesuai dengan format GitHub Packages
docker tag $IMAGE_NAME:$TAG $GITHUB_REPO:$TAG

# Login ke GitHub Packages menggunakan environment variable
echo $PASSWORD_GHCR | docker login ghcr.io --username $GITHUB_USERNAME --password-stdin

# Push image ke GitHub Packages
docker push $GITHUB_REPO:$TAG

